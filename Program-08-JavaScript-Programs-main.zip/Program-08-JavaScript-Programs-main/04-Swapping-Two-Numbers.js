let a = 10;
let b = 20;

console.log("Before Swapping:");
console.log("a =", a);
console.log("b =", b);

let temp = a;
a = b;
b = temp;

console.log("After Swapping:");
console.log("a =", a);
console.log("b =", b);